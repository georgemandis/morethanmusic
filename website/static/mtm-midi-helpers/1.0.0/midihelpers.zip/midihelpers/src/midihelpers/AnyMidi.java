// Generated from midi-helpers/java/AnyMidi.pde by processing-library/generate.mjs. Edit the tab, not this file.
package midihelpers;

import processing.core.*;
import processing.data.*;
import processing.event.*;
import java.util.*;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiDevice;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.SysexMessage;
import javax.sound.midi.Receiver;
import javax.sound.midi.Transmitter;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import static processing.core.PApplet.*;
import static midihelpers.MidiCore.*;

public class AnyMidi implements MidiHandler {
  public PApplet app;
  public MidiCore core;
  public int[] notes = new int[128], ccs = new int[128];
  public int lastNote = -1, lastVelocity = -1, lastCC = -1, lastCCValue = -1, lastChannel = -1, pitchBend = 0, pressure = 0, count = 0;
  public String lastDevice = "";
  public MidiMsg last = null;

  public AnyMidi(PApplet app) { this(app, ""); }
  public AnyMidi(PApplet app, String name) {
    this.app = app;
    core = new MidiCore(app, name);
    core.label = "AnyMidi";
    java.util.Arrays.fill(notes, -1);
    java.util.Arrays.fill(ccs, -1);
    app.registerMethod("pre", this);
    app.registerMethod("dispose", this);
  }

  public boolean connect() { return core.connect(); }
  public boolean connected() { return core.hasInput(); }
  public String status() { return core.status; }
  public String[] devices() { return core.inputNames.toArray(new String[0]); }

  public int note(int n) { return n >= 0 && n < 128 ? notes[n] : -1; }
  public int cc(int n) { return n >= 0 && n < 128 ? ccs[n] : -1; }
  public boolean down(int n) { return note(n) > 0; }

  public void midi(MidiMsg m) {
    count++;
    last = m;
    lastDevice = m.device;
    if (m.channel > 0) lastChannel = m.channel;
    if (m.isNoteOn()) { notes[m.data1] = m.data2; lastNote = m.data1; lastVelocity = m.data2; }
    else if (m.isNoteOff()) { notes[m.data1] = 0; lastNote = m.data1; lastVelocity = 0; }
    else if (m.isControlChange()) { ccs[m.data1] = m.data2; lastCC = m.data1; lastCCValue = m.data2; }
    else if (m.isPitchBend()) { pitchBend = m.pitchBend(); core.callSketch("pitchBend", m.channel, pitchBend, m.device); }
    else if (m.type == 0xD0) pressure = m.data1;
    core.dispatchGeneric(m);
    if (m.sysex == null && !m.isNoteOn() && !m.isNoteOff() && !m.isControlChange()) core.callSketch("midiMessage", m.status, m.data1, m.data2, m.device);
  }

  public void pre() { core.poll(this); }

  public void send(int status, int data1, int data2) { core.send(status, data1, data2); }
  public void noteOn(int channel, int note, int velocity) { core.noteOn(channel, note, velocity); }
  public void noteOff(int channel, int note) { core.noteOff(channel, note); }
  public void noteOff(int channel, int note, int velocity) { core.noteOff(channel, note, velocity); }
  public void controlChange(int channel, int number, int value) { core.controlChange(channel, number, value); }
  public void programChange(int channel, int program) { core.programChange(channel, program); }
  public void pitchBend(int channel, int value) { core.pitchBend(channel, value); }
  public void sysex(int[] bytes) { core.sysex(bytes); }
  public void sysex(byte[] bytes) { core.sysex(bytes); }

  public void dispose() { core.close(); }
}
