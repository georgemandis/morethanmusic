// Generated from midi-helpers/java/MidiCore.pde by processing-library/generate.mjs. Edit the tab, not this file.
package midihelpers;

import processing.core.*;
import processing.data.*;
import processing.event.*;
import java.util.*;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiDevice;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.SysexMessage;
import javax.sound.midi.Receiver;
import javax.sound.midi.Transmitter;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import static processing.core.PApplet.*;
import static midihelpers.MidiCore.*;

/** One decoded message. channel is 1..16, 0 for system messages. SysEx: type 0xF0, bytes in sysex. */
public class MidiMsg {
  public int status, type, channel, data1, data2, millis;
  public byte[] sysex;
  public String device = "";   // the input it came from
  public MidiMsg(int status, int data1, int data2, int millis) {
    this.status = status;
    this.data1 = data1;
    this.data2 = data2;
    this.millis = millis;
    if (status >= 0xF0) {
      type = status;
      channel = 0;
    } else {
      type = status & 0xF0;
      channel = (status & 0x0F) + 1;
    }
  }
  public boolean isNoteOn() { return type == 0x90 && data2 > 0; }
  public boolean isNoteOff() { return type == 0x80 || (type == 0x90 && data2 == 0); }
  public boolean isControlChange() { return type == 0xB0; }
  public boolean isPitchBend() { return type == 0xE0; }
  public int pitchBend() { return (data2 << 7 | data1) - 8192; }
  public String toString() {
    if (sysex != null) return "sysex(" + sysex.length + " bytes)";
    String name = type == 0x90 ? (data2 > 0 ? "noteOn" : "noteOff") : type == 0x80 ? "noteOff" : type == 0xB0 ? "cc" :
      type == 0xE0 ? "pitchBend" : type == 0xD0 ? "aftertouch" : type == 0xC0 ? "program" : type == 0xA0 ? "polyTouch" : "status";
    return name + " ch" + channel + " " + data1 + " " + data2;
  }
}
