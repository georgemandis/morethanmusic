// Generated from midi-helpers/java/Trinkeys.pde by processing-library/generate.mjs. Edit the tab, not this file.
package midihelpers;

import processing.core.*;
import processing.data.*;
import processing.event.*;
import java.util.*;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiDevice;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.SysexMessage;
import javax.sound.midi.Receiver;
import javax.sound.midi.Transmitter;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import static processing.core.PApplet.*;
import static midihelpers.MidiCore.*;

public class SlideTrinkey implements MidiHandler {
  public final int CC_SLIDER = 1, NOTE_TOUCH = 60;
  public PApplet app;
  public MidiCore core;
  public float value = 0;
  public int raw = -1;
  public boolean touched = false;
  public boolean jt = false, jr = false, keyTouch = false, keyLeft = false, keyRight = false;

  public SlideTrinkey(PApplet app) { this(app, "Slide Trinkey"); }
  public SlideTrinkey(PApplet app, String name) {
    this.app = app;
    core = new MidiCore(app, name);
    core.label = "SlideTrinkey";
    app.registerMethod("pre", this);
    app.registerMethod("keyEvent", this);
    app.registerMethod("dispose", this);
  }
  public boolean connect() { return core.connect(); }
  public boolean connected() { return core.hasInput(); }
  public boolean justTouched() { return jt; }
  public boolean justReleased() { return jr; }
  /** Note On to the board: pixel colour from the note number, about a second. */
  public void pixel(int note) { core.noteOn(1, note, 127); core.noteOff(1, note); }

  public void midi(MidiMsg m) {
    core.dispatchGeneric(m);
    if (m.isControlChange() && m.data1 == CC_SLIDER) setRaw(m.data2);
    else if (m.data1 == NOTE_TOUCH && (m.isNoteOn() || m.isNoteOff())) setTouch(m.isNoteOn());
  }
  public void setRaw(int v) {
    if (v == raw) return;
    raw = v; value = v / 127f;
    core.callSketch("sliderChanged", value);
  }
  public void setTouch(boolean on) {
    if (on == touched) return;
    touched = on;
    if (on) { jt = true; core.callSketch("touchPressed"); } else { jr = true; core.callSketch("touchReleased"); }
  }
  public void pre() {
    jt = jr = false;
    core.poll(this);
    if (!connected()) {
      if (keyLeft || keyRight) setRaw(constrain((raw < 0 ? 64 : raw) + (keyRight ? 2 : -2), 0, 127));
      setTouch(keyTouch);
    }
  }
  public void keyEvent(KeyEvent e) {
    if (connected() || (e.getAction() != KeyEvent.PRESS && e.getAction() != KeyEvent.RELEASE)) return;
    boolean down = e.getAction() == KeyEvent.PRESS;
    if (e.getKeyCode() == LEFT) keyLeft = down;
    else if (e.getKeyCode() == RIGHT) keyRight = down;
    else if (Character.toLowerCase(e.getKey()) == 't') keyTouch = down;
  }
  public void dispose() { core.close(); }
}
