// Generated from midi-helpers/java/Trinkeys.pde by processing-library/generate.mjs. Edit the tab, not this file.
package midihelpers;

import processing.core.*;
import processing.data.*;
import processing.event.*;
import java.util.*;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiDevice;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.SysexMessage;
import javax.sound.midi.Receiver;
import javax.sound.midi.Transmitter;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import static processing.core.PApplet.*;
import static midihelpers.MidiCore.*;

public class RotaryTrinkey implements MidiHandler {
  public final int CC_ABSOLUTE = 2, CC_RELATIVE = 3, NOTE_PRESS = 61, NOTE_TOUCH = 62;
  public PApplet app;
  public MidiCore core;
  public float value = 0;
  public int raw = -1, delta = 0;
  public boolean pressed = false, touched = false;
  public int pendingDelta = 0;
  public boolean jp = false, jpr = false, jt = false, jtr = false, keyPress = false, keyTouch = false;
  public int keyDelta = 0;

  public RotaryTrinkey(PApplet app) { this(app, "Rotary Trinkey"); }
  public RotaryTrinkey(PApplet app, String name) {
    this.app = app;
    core = new MidiCore(app, name);
    core.label = "RotaryTrinkey";
    app.registerMethod("pre", this);
    app.registerMethod("keyEvent", this);
    app.registerMethod("dispose", this);
  }
  public boolean connect() { return core.connect(); }
  public boolean connected() { return core.hasInput(); }
  public boolean justPressed() { return jp; }
  public boolean justReleased() { return jpr; }
  public boolean justTouched() { return jt; }
  public boolean justTouchReleased() { return jtr; }
  public void pixel(int note) { core.noteOn(1, note, 127); core.noteOff(1, note); }
  /** Relative CC value as signed clicks: 1..63 clockwise, 65..127 counter-clockwise. */
  public int relative(int v) { return v < 64 ? v : v - 128; }

  public void midi(MidiMsg m) {
    core.dispatchGeneric(m);
    if (m.isControlChange()) {
      if (m.data1 == CC_ABSOLUTE) { raw = m.data2; value = raw / 127f; }
      else if (m.data1 == CC_RELATIVE) pendingDelta += relative(m.data2);
    } else if (m.isNoteOn() || m.isNoteOff()) {
      if (m.data1 == NOTE_PRESS) setPressed(m.isNoteOn());
      else if (m.data1 == NOTE_TOUCH) setTouch(m.isNoteOn());
    }
  }
  public void setPressed(boolean on) {
    if (on == pressed) return;
    pressed = on;
    if (on) { jp = true; core.callSketch("knobPressed"); } else { jpr = true; core.callSketch("knobReleased"); }
  }
  public void setTouch(boolean on) {
    if (on == touched) return;
    touched = on;
    if (on) { jt = true; core.callSketch("touchPressed"); } else { jtr = true; core.callSketch("touchReleased"); }
  }
  public void pre() {
    jp = jpr = jt = jtr = false;
    pendingDelta = 0;
    core.poll(this);
    if (!connected()) {
      pendingDelta += keyDelta; keyDelta = 0;
      if (pendingDelta != 0) { raw = constrain((raw < 0 ? 64 : raw) + pendingDelta, 0, 127); value = raw / 127f; }
      setPressed(keyPress);
      setTouch(keyTouch);
    }
    delta = pendingDelta;
    if (delta != 0) core.callSketch("knobTurned", delta);
  }
  public void keyEvent(KeyEvent e) {
    if (connected()) return;
    if (e.getAction() == KeyEvent.PRESS) {
      if (e.getKeyCode() == LEFT) keyDelta--;
      else if (e.getKeyCode() == RIGHT) keyDelta++;
    }
    if (e.getAction() != KeyEvent.PRESS && e.getAction() != KeyEvent.RELEASE) return;
    boolean down = e.getAction() == KeyEvent.PRESS;
    if (e.getKey() == ENTER || e.getKey() == RETURN) keyPress = down;
    else if (Character.toLowerCase(e.getKey()) == 't') keyTouch = down;
  }
  public void dispose() { core.close(); }
}
