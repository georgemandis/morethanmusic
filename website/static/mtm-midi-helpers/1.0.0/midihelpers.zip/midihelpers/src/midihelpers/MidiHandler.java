// Generated from midi-helpers/java/MidiCore.pde by processing-library/generate.mjs. Edit the tab, not this file.
package midihelpers;

import processing.core.*;
import processing.data.*;
import processing.event.*;
import java.util.*;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiDevice;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.SysexMessage;
import javax.sound.midi.Receiver;
import javax.sound.midi.Transmitter;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import static processing.core.PApplet.*;
import static midihelpers.MidiCore.*;

/** poll() calls midi(msg) for each queued message. */
public interface MidiHandler {
  public void midi(MidiMsg msg);
}
