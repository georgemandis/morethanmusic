// Generated from midi-helpers/java/PipSqueak.pde by processing-library/generate.mjs. Edit the tab, not this file.
package midihelpers;

import processing.core.*;
import processing.data.*;
import processing.event.*;
import java.util.*;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiDevice;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.SysexMessage;
import javax.sound.midi.Receiver;
import javax.sound.midi.Transmitter;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import static processing.core.PApplet.*;
import static midihelpers.MidiCore.*;

public class PipSqueak implements MidiHandler {
  public PApplet app;
  public MidiCore core;
  public PipSqueakConfig config;
  public float x = 0, y = 0, angle = Float.NaN, magnitude = 0;
  public boolean pressed = false;
  public int rawX, rawY;
  public boolean buttonRaw = false, justPressedFlag = false, justReleasedFlag = false;
  public float sx = 0, sy = 0;
  public ArrayList<int[]> sampling = null;
  public int sampleUntil = 0;
  public boolean keyLeft, keyRight, keyUp, keyDown, keySpace;

  public PipSqueak(PApplet app) { this(app, null, (PipSqueakConfig) null); }
  public PipSqueak(PApplet app, String name) { this(app, name, (PipSqueakConfig) null); }
  public PipSqueak(PApplet app, String name, JSONObject config) { this(app, name, new PipSqueakConfig(config)); }
  public PipSqueak(PApplet app, PipSqueakConfig config) { this(app, null, config); }
  public PipSqueak(PApplet app, String name, PipSqueakConfig config) {
    this.app = app;
    this.config = config == null ? new PipSqueakConfig() : config;
    if (name == null) name = this.config.name;
    core = new MidiCore(app, name, null);
    core.label = "PipSqueak";
    rawX = this.config.xCenter;
    rawY = this.config.yCenter;
    app.registerMethod("pre", this);
    app.registerMethod("keyEvent", this);
    app.registerMethod("dispose", this);
  }

  public boolean connect() { return core.connect(); }
  public boolean connected() { return core.hasInput(); }
  public boolean justPressed() { return justPressedFlag; }

  /** Note On 60 velocity 127, then Note Off. The device's LED rule does the rest. */
  public void flash() { send(0x90, 60, 127); send(0x80, 60, 0); }
  /** Any message to the stick's own port. Opens it on first use. */
  public void send(int status, int data1, int data2) {
    if (!ensureOutput()) return;
    core.send(status, data1, data2);
  }
  public boolean outputWarned = false;
  public boolean ensureOutput() {
    if (core.hasOutput()) return true;
    if (core.connectOutput(core.inputFilter)) return true;
    if (!outputWarned) { outputWarned = true; println("PipSqueak: no output port; flash() and send() do nothing"); }
    return false;
  }
  public boolean justReleased() { return justReleasedFlag; }

  /** Sample the rest position for `seconds` (hands off) and make it the centre. */
  public void recenter(float seconds) {
    sampling = new ArrayList<int[]>();
    sampling.add(new int[] { rawX, rawY });
    sampleUntil = app.millis() + (int) (seconds * 1000);
  }
  public void recenter() { recenter(0.5f); }

  public boolean xSeen = false, ySeen = false;

  /** Auto mode. Adopt a known map the first time the unit speaks it. Snap each axis centre to its first
   *  value when that value is near the map's rest, because the first message arrives as the stick leaves rest. */
  public void learn(MidiMsg m) {
    PipSqueakConfig[] known = config.profiles();
    if (!config.claims(m) && config.profile.equals(known[0].profile)) {   // switch once, away from the default
      for (PipSqueakConfig p : known) {
        if (p.claims(m) && !p.profile.equals(config.profile)) {
          config.adopt(p);
          rawX = config.xCenter; rawY = config.yCenter; xSeen = ySeen = false;
          if (core.verbose) println("PipSqueak: using the '" + p.profile + "' map (x cc" + p.xCC + ", y cc" + p.yCC + ", button " + (p.buttonNote >= 0 ? "note " + p.buttonNote : "cc" + p.buttonCC) + ")");
          break;
        }
      }
    }
    if (m.isControlChange()) {
      if (m.data1 == config.xCC && !xSeen) { xSeen = true; if (abs(m.data2 - config.xCenter) <= 12) config.xCenter = m.data2; }
      if (m.data1 == config.yCC && !ySeen) { ySeen = true; if (abs(m.data2 - config.yCenter) <= 12) config.yCenter = m.data2; }
    }
  }


  public void midi(MidiMsg m) {
    core.dispatchGeneric(m);
    if (config.auto) learn(m);
    if (m.isControlChange()) {
      if (m.data1 == config.xCC) rawX = m.data2;
      else if (m.data1 == config.yCC) rawY = m.data2;
      else if (m.data1 == config.buttonCC) setButton(m.data2 >= config.buttonThreshold);
      else return;
      if (sampling != null && (m.data1 == config.xCC || m.data1 == config.yCC)) sampling.add(new int[] { rawX, rawY });
    } else if (config.buttonNote >= 0 && m.data1 == config.buttonNote) {
      if (m.isNoteOn()) setButton(true);
      else if (m.isNoteOff()) setButton(false);
    }
  }

  public void setButton(boolean down) {
    if (down == buttonRaw) return;
    buttonRaw = down;
    if (down) { justPressedFlag = true; core.callSketch("stickPressed"); }
    else { justReleasedFlag = true; core.callSketch("stickReleased"); }
  }


  public void pre() {
    justPressedFlag = justReleasedFlag = false;
    core.poll(this);
    if (!connected()) setButton(keySpace);
    if (sampling != null && app.millis() >= sampleUntil) {
      long tx = 0, ty = 0;
      for (int[] s : sampling) { tx += s[0]; ty += s[1]; }
      config.xCenter = round(tx / (float) sampling.size());
      config.yCenter = round(ty / (float) sampling.size());
      sampling = null;
    }
    float nx, ny;
    if (!connected()) {
      nx = (keyRight ? 1 : 0) - (keyLeft ? 1 : 0);
      ny = (keyUp ? 1 : 0) - (keyDown ? 1 : 0);
      if (nx != 0 && ny != 0) { nx *= 0.7071f; ny *= 0.7071f; }
    } else {
      float[] n = config.normalize(rawX, rawY);
      nx = n[0]; ny = n[1];
    }
    float a = config.smoothing;
    sx += (nx - sx) * a;
    sy += (ny - sy) * a;
    if (abs(sx) < 1e-3) sx = 0;
    if (abs(sy) < 1e-3) sy = 0;
    x = sx; y = sy;
    magnitude = min(1, (float) Math.hypot(x, y));
    angle = magnitude > 0 ? atan2(y, x) : Float.NaN;
    pressed = buttonRaw;
  }

  /** Keyboard stand-in: arrows move, SPACE presses. */
  public void keyEvent(KeyEvent e) {
    if (connected()) return;
    if (e.getAction() != KeyEvent.PRESS && e.getAction() != KeyEvent.RELEASE) return;
    boolean down = e.getAction() == KeyEvent.PRESS;
    int code = e.getKeyCode();
    if (code == LEFT) keyLeft = down;
    else if (code == RIGHT) keyRight = down;
    else if (code == UP) keyUp = down;
    else if (code == DOWN) keyDown = down;
    else if (e.getKey() == ' ') keySpace = down;
  }

  public void dispose() { core.close(); }
}
