// Generated from midi-helpers/java/PipSqueak.pde by processing-library/generate.mjs. Edit the tab, not this file.
package midihelpers;

import processing.core.*;
import processing.data.*;
import processing.event.*;
import java.util.*;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiDevice;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.SysexMessage;
import javax.sound.midi.Receiver;
import javax.sound.midi.Transmitter;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import static processing.core.PApplet.*;
import static midihelpers.MidiCore.*;

public class PipSqueakConfig {
  public String name = "pipsqueak";
  public int xCC = 17, xCenter = 60, xMin = 0, xMax = 126;
  public int yCC = 20, yCenter = 68, yMin = 0, yMax = 126;
  public boolean xInvert = false, yInvert = false;
  public int buttonCC = 25, buttonThreshold = 64, buttonNote = -1;
  public float deadzone = 0.1f, smoothing = 1.0f;
  public boolean auto = true;          // switch once to a known map when the unit speaks it; snap the centre to the first resting value
  public String profile = "stock";

  public PipSqueakConfig() {}

  /** Maps seen on real units. Index 0 is the default. */
  public PipSqueakConfig[] profiles() {
    PipSqueakConfig stock = new PipSqueakConfig();
    PipSqueakConfig usemidi = new PipSqueakConfig();
    usemidi.profile = "usemidi";
    usemidi.xCC = 10; usemidi.xCenter = 67;
    usemidi.yCC = 7;  usemidi.yCenter = 70;
    usemidi.buttonCC = -1; usemidi.buttonNote = 60;
    return new PipSqueakConfig[] { stock, usemidi };
  }

  /** Take another profile's map and centres. Keeps name, deadzone and smoothing. */
  public void adopt(PipSqueakConfig p) {
    profile = p.profile;
    xCC = p.xCC; xCenter = p.xCenter; xMin = p.xMin; xMax = p.xMax; xInvert = p.xInvert;
    yCC = p.yCC; yCenter = p.yCenter; yMin = p.yMin; yMax = p.yMax; yInvert = p.yInvert;
    buttonCC = p.buttonCC; buttonThreshold = p.buttonThreshold; buttonNote = p.buttonNote;
  }

  /** Does this map claim the message? */
  public boolean claims(MidiMsg m) {
    if (m.isControlChange()) return m.data1 == xCC || m.data1 == yCC || m.data1 == buttonCC;
    if (m.isNoteOn() || m.isNoteOff()) return buttonNote >= 0 && m.data1 == buttonNote;
    return false;
  }

  /** Same shape as the JS and Python configs. Missing keys keep their defaults. */
  public PipSqueakConfig(JSONObject json) {
    if (json == null) return;
    auto = json.getBoolean("auto", false);   // an explicit config means what it says
    profile = json.getString("profile", "custom");
    name = json.getString("name", name);
    deadzone = json.getFloat("deadzone", deadzone);
    smoothing = json.getFloat("smoothing", smoothing);
    if (json.hasKey("x")) {
      JSONObject a = json.getJSONObject("x");
      xCC = a.getInt("cc", xCC); xCenter = a.getInt("center", xCenter); xMin = a.getInt("min", xMin); xMax = a.getInt("max", xMax); xInvert = a.getBoolean("invert", xInvert);
    }
    if (json.hasKey("y")) {
      JSONObject a = json.getJSONObject("y");
      yCC = a.getInt("cc", yCC); yCenter = a.getInt("center", yCenter); yMin = a.getInt("min", yMin); yMax = a.getInt("max", yMax); yInvert = a.getBoolean("invert", yInvert);
    }
    if (json.hasKey("button")) {
      JSONObject b = json.getJSONObject("button");
      buttonCC = b.getInt("cc", buttonCC); buttonThreshold = b.getInt("threshold", buttonThreshold); buttonNote = b.getInt("note", buttonNote);
    }
  }

  /** Raw 0..127 to -1..1, piecewise-linear around the rest value. */
  public float normalizeAxis(int value, int center, int lo, int hi, boolean invert) {
    float n;
    if (value >= center) n = hi > center ? (value - center) / (float) (hi - center) : 0;
    else n = center > lo ? (value - center) / (float) (center - lo) : 0;
    n = constrain(n, -1, 1);
    return invert ? -n : n;
  }

  /** Raw x/y to {x, y, angle, magnitude}. Radial deadzone; angle is NaN inside it. */
  public float[] normalize(int rawX, int rawY) {
    float x = normalizeAxis(rawX, xCenter, xMin, xMax, xInvert);
    float y = normalizeAxis(rawY, yCenter, yMin, yMax, yInvert);
    float magnitude = min(1, (float) Math.hypot(x, y));
    if (magnitude < deadzone) return new float[] { 0, 0, Float.NaN, 0 };
    float scaled = (magnitude - deadzone) / (1 - deadzone);
    float angle = atan2(y, x);
    return new float[] { cos(angle) * scaled, sin(angle) * scaled, angle, scaled };
  }
}
